i3status | while :
do
        read line
        playing=$(ncmpcpp --current-song {%f})
        echo "$playing | $line" || exit 1
done